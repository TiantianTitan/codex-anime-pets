# Dan Heng · Imbibitor Lunae 丹恒·饮月 · Motion 候选

Local review candidate from GitHub main 0a7cb6d, 2026-11-06.

Only idle row 0 columns 0–5 and running row 7 columns 0–5 are redrawn with built-in ImageGen. All other cells, including neutral and the 16 look directions, are pixel-identical to the approved original.

This package does not change client timing or enable persistent state loops. Version 2, 1536×2288 RGBA. Use the independent ID dan-heng-imbibitor-lunae-motion-candidate to compare alongside the original.
