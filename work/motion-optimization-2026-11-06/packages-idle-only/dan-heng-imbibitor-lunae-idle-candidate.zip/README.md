# Dan Heng · Imbibitor Lunae 丹恒·饮月 · 待机候选

仅修复慢速待机的长时间闭眼。只替换第 0 行前六格，其他 82 格（含 68 个已用格）与原版逐像素一致；工作姿态保持原版。

安装：解压到 CODEX_HOME/pets/dan-heng-imbibitor-lunae-idle-candidate/（默认 ~/.codex/pets/），确保 pet.json 直接位于该目录中。随后在 Settings > Pets 中 Refresh，选择角色，用 /pet 显示。

v2 / 1536×2288 RGBA。候选使用独立 ID，可与原版并存。
